README

1. First run "npm install" to install any dependencies needed by the system
2. Then run "npm run deploy" to deploy updated lambda code to AWS
